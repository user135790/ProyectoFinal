/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agenciaViajes.negocio;
import agenciaViajes.acceso.IServidor;
import agenciaViajes.acceso.ServicioServidor;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.Properties;
/**
 *
 * @author Santiago
 */
public class GestorClientes {
    private IServidor servidor;
    
    /**
     * Constructor
     */
    public GestorClientes() {
        servidor=new ServicioServidor();
    }
    
    
        /**
     * Busca a el cliente en el servidor
     *
     * @param documento documento de identidad del cliente que se desea buscar
     * @return cliente buscado o null si no lo encuentra
     */
    public ArrayList<Cliente> buscarClienteRegistraduria(String documento) {
        //Obtiene el objeto json serializado al servidor de la registraduria
        String json = servidor.obtenerUnCliente(documento);
        if (!json.equals("NO_ENCONTRADO")) {
            //Lo encontró
            ArrayList<Cliente> cliente = new ArrayList<>();
            parseToArrayList(cliente, json);
            return cliente;
        }

        return null;
    }

    /**
     * Busca todos los clientes en el servidor
     *
     * @return lista de clientes en el servidor convertidos de json a ArrayList
     */
    public ArrayList<Cliente> buscarClientes() {
        //Obtiene el objeto json serializado al servidor de la registraduria
        String json = servidor.obtenerClientes();

        if (!json.equals("NO_ENCONTRADO")) {
            //Lo encontró
            ArrayList<Cliente> cliente = new ArrayList<>();
            parseToArrayList(cliente, json);
            return cliente;
        }

        return null;
    }

    /**
     * Elimina a un cliente de servidor
     *
     * @param documento
     */
    public void EliminarClienteRegistraduria(String documento) {
        String json = servidor.obtenerUnCliente(documento);
        if (!json.equals("NO_ENCONTRADO")) {
            //Lo encontró
            servidor.EliminarClienteDelServidor(documento);
        }
        
    }

    /**
     * Agrega a un cliente en el servidor
     *
     * @param cli
     */
    public void AgregarClienteRegistraduria(Cliente cli) {
        String json = servidor.AgregarClienteDelServidor(cli);
        if (!json.equals("NO_ENCONTRADO")) {
            //Lo encontró
            servidor.AgregarClienteDelServidor(cli);
        } 
    }

    
    /**
     * Convierte de json a una lista de clientes 
     * 
     * @param cliente lista de clientes vacia
     * @param json el json que devuelve la comunicacion con el servidor
     */
    private void parseToArrayList(ArrayList<Cliente> cliente, String json) {
        Gson gson = new Gson();
        Properties properties = gson.fromJson(json, Properties.class);
        int tamano;
        tamano=Integer.parseInt(properties.getProperty("tamano"));
        
        for(int i=0;i<tamano;i++){
        Cliente clienteaux=new Cliente();
        clienteaux.setDocumentoIdentidad(properties.getProperty("documento"+i));
        clienteaux.setNombre(properties.getProperty("nombres"+i));
        clienteaux.setApellidos(properties.getProperty("apellidos"+i));
        clienteaux.setFechaNacimiento(properties.getProperty("fechaNacimiento"+i));
        clienteaux.setEmail(properties.getProperty("email"+i));
        clienteaux.setGenero(properties.getProperty("genero"+i));
        clienteaux.setDireccion(properties.getProperty("direccion"+i));
        clienteaux.setCiudadResidencia(properties.getProperty("ciudadResidencia"+i));
        clienteaux.setCelular(properties.getProperty("celular"+i));
        cliente.add(clienteaux);
        }
        
    }
   

    /**
     * Edita un cliente en la base de datos
     *
     * @param documento
     * @param nombres
     * @param apellidos
     * @param fecha_nacimiento
     * @param direccion
     * @param genero
     * @param celular
     * @param email
     * @param ciudad_residencia
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    /*public void editarCliente(String documento, String nombres, String apellidos, String fecha_nacimiento, String email, String genero, String direccion, String ciudad_residencia, String celular) throws ClassNotFoundException, SQLException {
        intermediario.conectar();
        intermediario.actualizar("UPDATE Cliente SET "
                + "nombres = '" + nombres + "',"
                + "apellidos ='" + apellidos + "',"
                + "fecha_nacimiento ='" + fecha_nacimiento + "',"
                + "email ='" + email + "',"
                + "genero ='" + genero + "',"
                + "direccion ='" + direccion + "',"
                + "ciudad_residencia ='" + ciudad_residencia + "',"
                + "celular = '" + celular + "'"
                + " WHERE documento ='" + documento
                + "'");
        intermediario.desconectarse();
    }
*/
}