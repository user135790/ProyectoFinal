/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agenciaViajes.negocio;

import agenciaViajes.acceso.IServidor;
import agenciaViajes.acceso.ServicioServidor;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.Properties;

/**
 *
 * @author Santiago
 */
public class GestorUsuarios {
    private IServidor servidor;
    
    public GestorUsuarios() {
        servidor = new ServicioServidor();
    }
    
    public void AgregarUsuario(Usuario cli) {
        String json = servidor.AgregarUsuario(cli);
        if (!json.equals("NO_ENCONTRADO")) {
            //Lo encontró
        }
    }
    
    public void AgregarAHistorial(Ingresos cli) {
        String json = servidor.AgregarHistorial(cli.getId(),cli.getFecha(),cli.getHora());
        if (!json.equals("NO_ENCONTRADO")) {
            //Lo encontró
        }
    }
    
    public void EliminarUsuario(String documento) {
        String json = servidor.consultarUsuario(documento);
        if (!json.equals("NO_ENCONTRADO")) {
            //Lo encontró
            servidor.BorrarUsuario(documento);
        }

    }
    
    public ArrayList<Ingresos> obtenerHistorial(String documento) {
        //Obtiene el objeto json serializado al servidor de la registraduria
        String json = servidor.consultarUsuario(documento);
        if (!json.equals("NO_ENCONTRADO")) {
            //Lo encontró
            ArrayList<Usuario> u = new ArrayList<>();
            ArrayList<Ingresos> i = new ArrayList<>();
            parseToArrayList(u, i, json);
            return i;
        }

        return null;
    }
    public ArrayList<Usuario> buscarUsuario(String documento) {
        //Obtiene el objeto json serializado al servidor de la registraduria
        String json = servidor.consultarUsuario(documento);
        if (!json.equals("NO_ENCONTRADO")) {
            //Lo encontró
            ArrayList<Usuario> u = new ArrayList<>();
            ArrayList<Ingresos> i =new ArrayList<>();
            parseToArrayList(u,i, json);
            return u;
        }

        return null;
    }
    
    private void parseToArrayList(ArrayList<Usuario> u,ArrayList<Ingresos> i, String json) {
        Gson gson = new Gson();
        Properties properties = gson.fromJson(json, Properties.class);
        int tamano;
        tamano = Integer.parseInt(properties.getProperty("tamano"));
        Usuario Uaux = new Usuario();
        Uaux.setId(properties.getProperty("id"));
        Uaux.setPermisos(properties.getProperty("permisos"));
        Uaux.setNombre(properties.getProperty("nombre"));
        Uaux.setContrasena(properties.getProperty("contrasena"));
        u.add(Uaux);
        for (int j = 0; j < tamano; j++) {
            Ingresos iaux=new Ingresos();
            iaux.setId(properties.getProperty("id"+j));
            iaux.setFecha(properties.getProperty("fecha"+j));
            iaux.setHora(properties.getProperty("hora"+j));
            i.add(iaux);
        }

    }
}
