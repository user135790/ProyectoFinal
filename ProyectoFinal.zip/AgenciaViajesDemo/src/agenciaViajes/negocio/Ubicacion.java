/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agenciaViajes.negocio;

/**
 *
 * @author Santiago
 */
public abstract class Ubicacion {
    private String Nombre;

    public Ubicacion(String Nombre) {
        this.Nombre = Nombre;
    }
    
    public void añadirUbicacion(Ubicacion u){
    }    
  
    public Ubicacion getUbicacion(int posicion){ 
        return this;
    }

    public String getNombre() {
        return Nombre;
    }
    
}
