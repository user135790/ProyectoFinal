/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agenciaViajes.negocio;

import agenciaViajes.acceso.IServidor;
import agenciaViajes.acceso.ServicioServidor;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.Properties;

/**
 *
 * @author Santiago
 */
public class GestorUbicaciones {
    
    public IServidor servidor;
    
    /**
     * Constructor
     */
    public GestorUbicaciones() {
        servidor = new ServicioServidor();
    }
    
    
    public void AgregarUbicacion(String Continente, String Pais, String Ciudad) {
        String json = servidor.AgregarUbicacionAlServidor(Continente, Pais, Ciudad);
        if (json.equals("NO_ENCONTRADO")) {
            //Lo encontró
            System.out.println("No se encontró la accion");
        }
    }
    
    public ArrayList<String> buscarClientes() {
        //Obtiene el objeto json serializado al servidor de la registraduria
        String json = servidor.ConsultarUbicacion();
        if (!json.equals("NO_ENCONTRADO")) {
            //Lo encontró
            ArrayList<String> aux = new ArrayList<>();
            parseToArrayList(aux, json);
            return aux;
        }
        return null;
    }
    
    private void parseToArrayList(ArrayList<String> cliente, String json) {
        Gson gson = new Gson();
        Properties properties = gson.fromJson(json, Properties.class);
        int tamano;
        tamano = Integer.parseInt(properties.getProperty("tamano"));
        for (int i = 0; i < tamano; i++) {
            cliente.add(properties.getProperty("continente"+i));
            cliente.add(properties.getProperty("pais"+i));
            cliente.add(properties.getProperty("ciudad"+i));
        }
    }
}
