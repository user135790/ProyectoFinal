/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agenciaViajes.negocio;


import java.util.ArrayList;

/**
 *
 * @author Santiago
 */
public class UbicacionCompuesta extends Ubicacion {
    private ArrayList<Ubicacion> Lista = new ArrayList<>();

    public UbicacionCompuesta(String Nombre) {
        super(Nombre);
    }

    @Override
    public void añadirUbicacion(Ubicacion u) {
        Lista.add(u);
    }
    @Override
    public Ubicacion getUbicacion(int posicion){
        return Lista.get(posicion);
    }
}
