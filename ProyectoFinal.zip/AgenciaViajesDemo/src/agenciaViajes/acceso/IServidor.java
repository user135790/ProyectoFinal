/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agenciaViajes.acceso;

import agenciaViajes.negocio.Cliente;
import agenciaViajes.negocio.Ingresos;
import agenciaViajes.negocio.Usuario;
/**
 *
 * @author Santiago
 */
public interface IServidor {
        public String obtenerUnCliente(String id);
        public String AgregarClienteDelServidor(Cliente cli);
        public String EliminarClienteDelServidor(String id);
        public String obtenerClientes();
        public String AgregarUbicacionAlServidor(String continente, String Pais, String Ciudad);
        public String ConsultarUbicacion();
        public String AgregarUsuario(Usuario u);
        public String BorrarUsuario(String id);
        public String consultarUsuario(String id);
        public String AgregarHistorial(String id, String hecha,String hora);
}
