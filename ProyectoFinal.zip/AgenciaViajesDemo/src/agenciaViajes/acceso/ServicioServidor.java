/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agenciaViajes.acceso;

import agenciaViajes.negocio.Cliente;
import agenciaViajes.negocio.Ingresos;
import agenciaViajes.negocio.Usuario;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Santiago
 */
public class ServicioServidor implements IServidor{

        private Socket socket = null;
        private Scanner entradaDecorada;
        private PrintStream salidaDecorada;
        private final String IP_SERVIDOR = "localhost";
        private final int PUERTO = 5000;

        /**
         * Obtiene el registro de un cliente en formato Json
         *
         * @param documento documento de cliente que desea buscar
         * @return el cliente en formato json
         */
        @Override
        public String obtenerUnCliente(String documento) {
            String respuesta=null;
            try {
                
                conectar(IP_SERVIDOR, PUERTO);
                respuesta = leerFlujoEntradaSalida(null,documento,1);
                cerrarFlujos();
                desconectar();

            } catch (IOException ex ) {
                Logger.getLogger(ServicioServidor.class.getName()).log(Level.SEVERE, null, ex);
            }
            return respuesta;

        }
        
         /**
          * Obtiene el registro de todos los clientes en formato Json
          *
          * @return los clientes en formato json
          */
        @Override
        public String obtenerClientes(){
            String respuesta = null;
            try {
                conectar(IP_SERVIDOR, PUERTO);
                respuesta = leerFlujoEntradaSalida(null,"",2);
                cerrarFlujos();
                desconectar();

            } catch (IOException ex) {
                Logger.getLogger(ServicioServidor.class.getName()).log(Level.SEVERE, null, ex);
            }
            return respuesta;
        }
        
        @Override
        public String AgregarHistorial(String id, String fecha, String hora){
            String respuesta = null;
            String aux = id + "," + fecha + "," + hora;
            try {
                conectar(IP_SERVIDOR, PUERTO);
                respuesta = leerFlujoEntradaSalida(null, aux, 10);
                cerrarFlujos();
                desconectar();

            } catch (IOException ex) {
                Logger.getLogger(ServicioServidor.class.getName()).log(Level.SEVERE, null, ex);
            }
            return respuesta;
        }
        
        @Override
        public String AgregarClienteDelServidor(Cliente cli){
            String respuesta = null;
            try {
                conectar(IP_SERVIDOR, PUERTO);
                respuesta = leerFlujoEntradaSalida(cli,"",3);
                cerrarFlujos();
                desconectar();

            } catch (IOException ex) {
                Logger.getLogger(ServicioServidor.class.getName()).log(Level.SEVERE, null, ex);
            }
            return respuesta;
        }
        
         
        @Override
        public String EliminarClienteDelServidor(String documento){
            String respuesta = null;
            try {
                conectar(IP_SERVIDOR, PUERTO);
                respuesta = leerFlujoEntradaSalida(null,documento,4);
                cerrarFlujos();
                desconectar();

            } catch (IOException ex) {
                Logger.getLogger(ServicioServidor.class.getName()).log(Level.SEVERE, null, ex);
            }
            return respuesta;
        }
        @Override
        public String AgregarUbicacionAlServidor(String continente, String Pais, String Ciudad){
            String respuesta = null;
            String aux=continente+","+Pais+","+Ciudad;
            try {
                conectar(IP_SERVIDOR, PUERTO);
                respuesta = leerFlujoEntradaSalida(null, aux, 5);
                cerrarFlujos();
                desconectar();

            } catch (IOException ex) {
                Logger.getLogger(ServicioServidor.class.getName()).log(Level.SEVERE, null, ex);
            }
            return respuesta;
        }
        @Override
        public String ConsultarUbicacion(){
            String respuesta = null;
            try {
                conectar(IP_SERVIDOR, PUERTO);
                respuesta = leerFlujoEntradaSalida(null, "", 6);
                cerrarFlujos();
                desconectar();

            } catch (IOException ex) {
                Logger.getLogger(ServicioServidor.class.getName()).log(Level.SEVERE, null, ex);
            }
            return respuesta;
        }
        
        
        public String ConsultarHistorial() {
        String respuesta = null;
        try {
            conectar(IP_SERVIDOR, PUERTO);
            respuesta = leerFlujoEntradaSalida(null, "", 11);
            cerrarFlujos();
            desconectar();

        } catch (IOException ex) {
            Logger.getLogger(ServicioServidor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return respuesta;
    }
        /**
        * Envia la peticion y recibe el flujo de datos de entrada
        *
        * @param documento documento de identidad en caso de buscar o eliminar un cliente
        * @param opcion depende de la accion que se quiera realizar en el servidor
        * @param Cliente cliente en caso de querer agregarlo en el servidor
        * 
        * @return los datos de entrada es decir datos en formato json
         */
        private String leerFlujoEntradaSalida(Cliente cli,String documento,int opcion) throws IOException {
            String respuesta = "";
            entradaDecorada = new Scanner(socket.getInputStream());
            salidaDecorada = new PrintStream(socket.getOutputStream());
            salidaDecorada.flush();
            // Usando el protocolo de comunicación
            switch(opcion){
                case 1:
                        salidaDecorada.println("consultarClientes," + documento);
                break;
                case 2:
                        salidaDecorada.println("ConsultarTodos");
                break;
                case 3:
                        salidaDecorada.println("AgregarCliente," + cli.getDocumentoIdentidad() 
                                            + "," + cli.getNombre() + "," + cli.getApellidos() + ","
                                            + cli.getFechaNacimiento() + "," + cli.getEmail() + "," 
                                            + cli.getGenero() + "," + cli.getDireccion() + "," 
                                            + cli.getCiudadResidencia() + "," + cli.getCelular());
                break;
                case 4:
                        salidaDecorada.println("EliminarCliente," + documento);
                break;
                case 5:
                        salidaDecorada.println("AgregarUbicacion,"+documento);
                break;
                case 6:
                        salidaDecorada.println("ConsultarUbicaciones");
                break;
                case 7:
                        salidaDecorada.println("AgregarUsuario," + documento);
                break;       
                case 8:
                        salidaDecorada.println("BorrarUsuario," + documento);
                break;
                case 9:
                        salidaDecorada.println("consultarUsuario," + documento);
                break;
                case 10:
                        salidaDecorada.println("AgregarHistorial," + documento);
                break;
                case 11:
                        salidaDecorada.println("consultarHistorial," + documento);
                break;
               
            }
            if (entradaDecorada.hasNextLine()) {
                respuesta = entradaDecorada.nextLine();
            }
            
            return respuesta;
        }
        
        /**
        * Cierra los flujos de datos tanto de entrada como de salida
        * @return el cliente en formato json
        */
        private void cerrarFlujos() {
            salidaDecorada.close();
            entradaDecorada.close();
        }
        
        /**
        * Se desconecta del servidor
        */
        private void desconectar() {
            try {
                socket.close();
            } catch (IOException ex) {
                Logger.getLogger(ServicioServidor.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        /**
        * Se conecta al servidor
        *
        * @param address
        * @param port
        */
        public void conectar(String address, int port) throws IOException {
            socket = new Socket(address, port);
            System.out.println("Conectado");
        }

    @Override
    public String AgregarUsuario(Usuario u) {
        String respuesta = null;
        String aux = u.getId()+","+u.getPermisos()+","+u.getNombre()+","+u.getContrasena();
        try {
            conectar(IP_SERVIDOR, PUERTO);
            respuesta = leerFlujoEntradaSalida(null, aux, 7);
            cerrarFlujos();
            desconectar();

        } catch (IOException ex) {
            Logger.getLogger(ServicioServidor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return respuesta;
    }

    @Override
    public String BorrarUsuario(String id) {
        String respuesta = null;
        try {
            conectar(IP_SERVIDOR, PUERTO);
            respuesta = leerFlujoEntradaSalida(null, id, 8);
            cerrarFlujos();
            desconectar();

        } catch (IOException ex) {
            Logger.getLogger(ServicioServidor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return respuesta;
    }

    @Override
    public String consultarUsuario(String id) {
        String respuesta = null;
        try {
            conectar(IP_SERVIDOR, PUERTO);
            respuesta = leerFlujoEntradaSalida(null, id, 9);
            cerrarFlujos();
            desconectar();

        } catch (IOException ex) {
            Logger.getLogger(ServicioServidor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return respuesta;
    }
}

