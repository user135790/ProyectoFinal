/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registraduriaclientes.servicio;

import com.google.gson.JsonObject;
import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;





import registraduriaclientes.negocio.Clientes;
import registraduriaclientes.negocio.Ingresos;
import registraduriaclientes.negocio.IntermediarioJDBC;
import registraduriaclientes.negocio.Ubicacion;
import registraduriaclientes.negocio.Usuario;
/**
 *
 * @author Santiago
 */

public class Servidor implements Runnable{


    private static ServerSocket ssock;
    private static Socket socket;

    private Scanner entradaDecorada;
    private PrintStream salidaDecorada;
    private static final int PUERTO = 5000;
    
    private IntermediarioJDBC intermediario ;
    

    /**
     * Constructor
     */
    public Servidor() {
    intermediario= new IntermediarioJDBC() ;
    }

    /**
     * Crea un nuevo puerto para escuchar las solicitudes
     * Queda en ciclo infinito para mantenerse esperando solicitudes
     * Cuando encuentra peticion crea un nuevo hilo 
     */
    public void iniciar() {
        abrirPuerto();

        while (true) {
            esperarAlCliente();
            lanzarHilo();
        }
    }

    /**
     * Crea un hilo cada que recibe una peticion
     */
    private static void lanzarHilo() {
        new Thread(new Servidor()).start();
    }
    
    /**
     * Abre el puerto para escuchar solicitudes
     */
    private static void abrirPuerto() {
        try {
            ssock = new ServerSocket(PUERTO);
            System.out.println("Escuchando por el puerto " + PUERTO);
        } catch (IOException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Espera que el cliente se conecte y le devuelve un socket
     */
    private static void esperarAlCliente() {
        try {
            socket = ssock.accept();
            System.out.println("Cliente conectado");
        } catch (IOException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Proceso de cada hilo
     */
    @Override
    public void run() {
        try {
            
            crearFlujos();
            leerFlujos();
            cerrarFlujos();

        } catch (IOException e) {
            System.out.println(e);
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Entrada y salida para recibir y enviar datos por medio de sockets
     * 
     * @throws IOException
     */
    private void crearFlujos() throws IOException {
        salidaDecorada = new PrintStream(socket.getOutputStream());
        entradaDecorada = new Scanner(socket.getInputStream());
    }

    /**
     * Lee los flujos entrantes del socket
     */
    private void leerFlujos() throws SQLException, ClassNotFoundException {
        if (entradaDecorada.hasNextLine()) {
            // Extrae el flujo que envía el cliente
            String peticion = entradaDecorada.nextLine();
            decodificarPeticion(peticion);

        } else {
            salidaDecorada.flush();
            salidaDecorada.println("NO_ENCONTRADO");
        }
    }

    /**
     * Decodifica la petición, extrayendo la acción y los parámetros
     *
     * @param peticion la entrada completa que se recibió
     * de la forma ("accion,"+parametros)
     */
    private void decodificarPeticion(String peticion) throws SQLException, ClassNotFoundException {
        StringTokenizer tokens = new StringTokenizer(peticion, ",");
        String parametros[] = new String[15];

        int i = 0;
        while (tokens.hasMoreTokens()) {
            parametros[i++] = tokens.nextToken();
        }
        String accion = parametros[0];
        procesarAccion(accion, parametros);

    }

    /**
     * Decide qué accion invocar y la ejecuta
     *
     * @param accion acción a procesar
     * @param parametros parámetros de la acción
     */
    private void procesarAccion(String accion, String parametros[]) throws SQLException, ClassNotFoundException {
        switch (accion) {
            case "consultarClientes":
               
                intermediario.conectar();
                intermediario.crearConsulta("SELECT * FROM cliente Where documento='" + parametros[1] + "'");

                ArrayList<Clientes> cliente =new ArrayList<>();
                if (intermediario.getResultado().next()) {
                    cliente.add(new Clientes(intermediario.getResultado().getString("documento"), intermediario.getResultado().getString("nombres"), intermediario.getResultado().getString("apellidos"), intermediario.getResultado().getString("fecha_nacimiento"), intermediario.getResultado().getString("email"), intermediario.getResultado().getString("genero"), intermediario.getResultado().getString("direccion"), intermediario.getResultado().getString("ciudad_residencia"), intermediario.getResultado().getString("celular")));
                } 
                intermediario.desconectarse();
                
                if (cliente.isEmpty()) {
                    salidaDecorada.println("NO_ENCONTRADO");
                } else {
                    salidaDecorada.println(parseArrayListToJson(cliente));
                }
            break;
            case "AgregarCliente":
               
                String documento=parametros[1];
                String nombres = parametros[2];
                String apellidos = parametros[3];
                String fecha_nacimiento = parametros[4];
                String email = parametros[5];
                String genero = parametros[6];
                String direccion = parametros[7];
                String ciudad_residencia = parametros[8];
                String celular = parametros[9];
                

                intermediario.conectar();
                intermediario.actualizar("INSERT INTO Cliente (documento, nombres, apellidos, fecha_nacimiento , email, genero,direccion,ciudad_residencia, celular)"
                        + " VALUES ("
                        + "'" + documento + "',"
                        + "'" + nombres + "',"
                        + "'" + apellidos + "',"
                        + "'" + fecha_nacimiento + "',"
                        + "'" + email + "',"
                        + "'" + genero + "',"
                        + "'" + direccion + "',"
                        + "'" + ciudad_residencia + "',"
                        + "'" + celular + "'"
                        + ")");
                intermediario.desconectarse();

            break;
            case "EliminarCliente":
                String documento2 = parametros[1];
                intermediario.conectar();
                intermediario.actualizar("DELETE FROM Cliente  "
                        + " WHERE documento ='" + documento2
                        + "'");
                intermediario.desconectarse();

            break;
            case "ConsultarTodos":
                
                intermediario.conectar();
                intermediario.crearConsulta("SELECT * FROM cliente");

                ArrayList<Clientes> clientes2 =new ArrayList<>();

                while (intermediario.getResultado().next()) {
                    Clientes cliente2 = new Clientes(intermediario.getResultado().getString("documento"), intermediario.getResultado().getString("nombres"), intermediario.getResultado().getString("apellidos"), intermediario.getResultado().getString("fecha_nacimiento"), intermediario.getResultado().getString("email"), intermediario.getResultado().getString("genero"), intermediario.getResultado().getString("direccion"), intermediario.getResultado().getString("ciudad_residencia"), intermediario.getResultado().getString("celular"));
                    clientes2.add(cliente2);
                }
                if (clientes2.isEmpty()) {
                    salidaDecorada.println("NO_ENCONTRADO");
                } else {
                    salidaDecorada.println(parseArrayListToJson(clientes2));
                }
                intermediario.desconectarse();
            break;  
            
            case "AgregarUbicacion":
                String continente = parametros[1];
                String pais = parametros[2];
                String ciudad = parametros[3];
                
                intermediario.conectar();
                intermediario.actualizar("INSERT INTO Ubicacion "
                        + " VALUES ("
                        + "'" + continente + "',"
                        + "'" + pais + "',"
                        + "'" + ciudad + "'"       
                        + ")");
                intermediario.desconectarse(); 
            break;
            case "ConsultarUbicaciones":
                intermediario.conectar();
                intermediario.crearConsulta("SELECT * FROM ubicacion");

                ArrayList<Ubicacion> ubicacion = new ArrayList<>();
              
                while (intermediario.getResultado().next()) {
                    
                    Ubicacion ubicacion2 = new Ubicacion(intermediario.getResultado().getString("continente"), intermediario.getResultado().getString("pais"), intermediario.getResultado().getString("ciudad"));
                    ubicacion.add(ubicacion2);
                }
                if (ubicacion.isEmpty()) {
                    salidaDecorada.println("NO_ENCONTRADO");
                } else {
                    salidaDecorada.println(parseArrayListToJson2(ubicacion));
                }
                intermediario.desconectarse();
            break;
            
                case "AgregarUsuario":
                String id = parametros[1];
                String permisos = parametros[2];
                String nombre = parametros[3];
                String contrasena = parametros[4];
                //String fecha = parametros[5];
                //String hora = parametros[6];

                intermediario.conectar();
                intermediario.actualizar("INSERT INTO Usuario (id,permisos,nombre,contrasena)"
                        + " VALUES ("
                        + "'" + id + "',"
                        + "'" + permisos + "',"
                        + "'" + nombre + "',"
                        + "'" + contrasena + "'"
                        + ")");
                intermediario.desconectarse();
            break;
            case "consultarUsuario":
                 
                intermediario.conectar();
                intermediario.crearConsulta("SELECT * FROM Usuario Where id='" + parametros[1] + "'");

                ArrayList<Usuario> u2 = new ArrayList<>();
                if (intermediario.getResultado().next()) {
                    u2.add(new Usuario(intermediario.getResultado().getString("id"), intermediario.getResultado().getString("permisos"), intermediario.getResultado().getString("nombre"), intermediario.getResultado().getString("contrasena")));
                }
                intermediario.crearConsulta("SELECT * FROM ingresos Where id='" + parametros[1] + "'");
                ArrayList<Ingresos> i = new ArrayList<>();
                if (intermediario.getResultado().next()) {
                    i.add(new Ingresos(intermediario.getResultado().getString("id"), intermediario.getResultado().getString("fecha"), intermediario.getResultado().getString("hora")));
                }
                intermediario.desconectarse();

                if (u2.isEmpty()) {
                    salidaDecorada.println("NO_ENCONTRADO");
                } else {
                    salidaDecorada.println(parseArrayListToJson4(u2,i));
                }
            break;
            case "BorrarUsuario":
                String id2 = parametros[1];
                intermediario.conectar();
                intermediario.actualizar("DELETE FROM usuario  "
                        + " WHERE id ='" + id2
                        + "'");
                intermediario.desconectarse();
            break;
            case "AgregarHistorial":
                String id3 = parametros[1];
                String fecha = parametros[2];
                String hora = parametros[3];
                //String fecha = parametros[5];
                //String hora = parametros[6];

                intermediario.conectar();
                intermediario.actualizar("INSERT INTO Ingresos (id,fecha,hora)"
                        + " VALUES ("
                        + "'" + id3 + "',"
                        + "'" + fecha + "',"
                        + "'" + hora + "'"
                        + ")");
                intermediario.desconectarse();
            break;
            
        }
    }

    /**
     * Cierra los flujos de entrada y salida
     *
     * @throws IOException
     */
    private void cerrarFlujos() throws IOException {
        salidaDecorada.close();
        entradaDecorada.close();
        socket.close();
    }

    private String parseArrayListToJson4(ArrayList<Usuario> cli, ArrayList<Ingresos> i) {
        JsonObject jsonobj = new JsonObject();
        jsonobj.addProperty("tamano", i.size());
        jsonobj.addProperty("id", cli.get(0).getId());
        jsonobj.addProperty("permisos", cli.get(0).getPermisos());
        jsonobj.addProperty("nombre", cli.get(0).getNombre());
        jsonobj.addProperty("contrasena", cli.get(0).getContrasena());
        for (int j = 0; j < i.size(); j++) {
            jsonobj.addProperty("id" + j, i.get(j).getId());
            jsonobj.addProperty("fecha" + j, i.get(j).getFecha());
            jsonobj.addProperty("hora" + j, i.get(j).getHora());
        }
        return jsonobj.toString();
    }
    
    private String parseArrayListToJson2(ArrayList<Ubicacion> cli) {
        JsonObject jsonobj = new JsonObject();
        jsonobj.addProperty("tamano", cli.size());
        for (int i = 0; i < cli.size(); i++) {
            jsonobj.addProperty("continente" + i, cli.get(i).getContinente());
            jsonobj.addProperty("pais" + i, cli.get(i).getPais());
            jsonobj.addProperty("ciudad" + i, cli.get(i).getCiudad());
        }
        return jsonobj.toString();
    }
    
    /**
     * Convierte el objeto Cliente a json
     *
     * @param cli Objeto ciudadano
     * @return cadena json
     */
    private String parseArrayListToJson(ArrayList<Clientes> cli){
        JsonObject jsonobj = new JsonObject();
        jsonobj.addProperty("tamano", cli.size());
        for (int i=0;i<cli.size();i++){
        jsonobj.addProperty("documento"+i, cli.get(i).getDocumentoIdentidad());
        jsonobj.addProperty("nombres"+i, cli.get(i).getNombre());
        jsonobj.addProperty("apellidos"+i, cli.get(i).getApellidos());
        jsonobj.addProperty("fechaNacimiento"+i, cli.get(i).getFechaNacimiento());
        jsonobj.addProperty("email"+i, cli.get(i).getEmail());
        jsonobj.addProperty("genero"+i, cli.get(i).getGenero());
        jsonobj.addProperty("direccion"+i, cli.get(i).getDireccion());
        jsonobj.addProperty("ciudadResidencia"+i, cli.get(i).getCiudadResidencia());
        jsonobj.addProperty("celular"+i, cli.get(i).getCelular());
        
        }
        return jsonobj.toString();
    }
}
