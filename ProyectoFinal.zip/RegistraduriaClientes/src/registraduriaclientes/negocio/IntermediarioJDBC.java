/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registraduriaclientes.negocio;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
 
/**
 *
 * @author Santiago
 */
public class IntermediarioJDBC {
    private Connection conexion;
    private ResultSet resultadoConsulta;
    private Statement peticion;
    private final String url= "jdbc:hsqldb:file:C:\\Users\\ingesis\\Desktop\\AgenciaViajesDemo\\clientes;hsqldb.lock_file=false";
    private final String usuario = "SA";
    private final String clave = "123";
    
    public IntermediarioJDBC() {
    }
    
    public void conectar() throws ClassNotFoundException, SQLException {
        Class.forName("org.hsqldb.jdbcDriver");
        conexion = DriverManager.getConnection(url, usuario, clave);
    }
    
    /**
     * Ejecuta una consulta de tipo select
     *
     * @param sql
     * @throws SQLException
     */
    public void crearConsulta(String sql) throws SQLException {
        peticion = conexion.createStatement();
        resultadoConsulta = peticion.executeQuery(sql);
    }
    
    /**
     * Ejecuta una consulta de tipo insert, update o delete
     *
     * @param sql
     * @throws SQLException
     */
    public void actualizar(String sql) throws SQLException {
        peticion = conexion.createStatement();
        peticion.executeUpdate(sql);
    }
    
    /**
     * Cierra las variables de rs, st y cn que estén abiertas
     *
     * @throws SQLException
     */
    public void desconectarse() throws SQLException {
        if (resultadoConsulta != null) {
            resultadoConsulta.close();
        }
        peticion.close();
        conexion.close();
    }
    
    /**
     * Devuelve todo el conjunto de resultados
     *
     * @return
     */
    public ResultSet getResultado() {
        return resultadoConsulta;
    }
    
}
