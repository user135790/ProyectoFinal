/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registraduriaclientes.negocio;

/**
 *
 * @author Santiago
 */
public class Clientes {

    private String documentoIdentidad;
    private String nombre;
    private String apellidos;
    private String fechaNacimiento;
    private String email;
    private String genero;
    private String direccion;
    private String ciudadResidencia;
    private String celular;

    /**
     * Constructores
     */
    public Clientes(){
        
    }
    /**
     * @param documentoIdentidad Documento de identidad del cliente 
     * @param nombre Nombre del cliente
     * @param apellidos Apellidos del cliente
     * @param fechaNacimiento fecha de nacimiento del cliente
     * @param email correo electronico del cliente
     * @param genero genero del cliente 
     * @param direccion direccion del cliente 
     * @param ciudadResidencia ciudad de residencia del cliente 
     * @param celular numero de celular del cliente 
     */
    public Clientes(String documentoIdentidad, String nombre, String apellidos, String fechaNacimiento, String email, String genero, String direccion, String ciudadResidencia, String celular) {
        this.documentoIdentidad = documentoIdentidad;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.fechaNacimiento = fechaNacimiento;
        this.email = email;
        this.genero = genero;
        this.direccion = direccion;
        this.ciudadResidencia = ciudadResidencia;
        this.celular = celular;
    }

    
    /**
     * Metodos Getter and Setter
     */
    public String getDocumentoIdentidad() {
        return documentoIdentidad;
    }

    public void setDocumentoIdentidad(String documentoIdentidad) {
        this.documentoIdentidad = documentoIdentidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCiudadResidencia() {
        return ciudadResidencia;
    }

    public void setCiudadResidencia(String ciudadResidencia) {
        this.ciudadResidencia = ciudadResidencia;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

}
