/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registraduriaclientes.negocio;

/**
 *
 * @author Santiago
 */
public class Ubicacion {
    private String continente;
    private String pais;
    private String ciudad;

    public Ubicacion(){
        
    }
    public Ubicacion(String continente, String pais, String ciudad) {
        this.continente = continente;
        this.pais = pais;
        this.ciudad = ciudad;
    }

    public String getContinente() {
        return continente;
    }

    public void setContinente(String continente) {
        this.continente = continente;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }
    
    
}
